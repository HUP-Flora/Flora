-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stores`
--

DROP TABLE IF EXISTS `stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stores` (
  `s_id` bigint NOT NULL AUTO_INCREMENT,
  `u_id` bigint NOT NULL,
  `s_business_license` varchar(50) NOT NULL,
  `s_name` varchar(50) NOT NULL,
  `s_phone_number` varchar(50) NOT NULL,
  `region_1depth_name` varchar(100) NOT NULL,
  `region_2depth_name` varchar(50) NOT NULL,
  `region_3depth_name` varchar(50) NOT NULL,
  `address_name` varchar(300) NOT NULL,
  `s_lat` float NOT NULL,
  `s_lng` float NOT NULL,
  `s_desc` varchar(250) NOT NULL,
  `s_is_onair` varchar(15) DEFAULT 'OFF',
  `s_holiday` varchar(50) DEFAULT NULL,
  `s_start` bigint NOT NULL,
  `s_end` bigint NOT NULL,
  `s_img_original_name` varchar(150) DEFAULT NULL,
  `s_img_new_name` varchar(150) DEFAULT NULL,
  `s_img_path` varchar(500) DEFAULT NULL,
  `s_img_upload_time` timestamp NULL DEFAULT NULL,
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`s_id`),
  KEY `u_id_idx` (`u_id`),
  KEY `s_start_idx` (`s_start`),
  KEY `s_end_idx` (`s_end`),
  CONSTRAINT `s_end` FOREIGN KEY (`s_end`) REFERENCES `time_unit` (`tu_id`),
  CONSTRAINT `s_start` FOREIGN KEY (`s_start`) REFERENCES `time_unit` (`tu_id`),
  CONSTRAINT `s_u_id` FOREIGN KEY (`u_id`) REFERENCES `users` (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=341 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stores`
--

LOCK TABLES `stores` WRITE;
/*!40000 ALTER TABLE `stores` DISABLE KEYS */;
INSERT INTO `stores` VALUES (315,315,'123-12-31231','아름 꽃집','010-1234-1234','대전광역시','유성구','봉명동','대전 유성구 봉명동 563-15/2층',36.3686,127.428,'안녕하세요 아름 꽃집입니다 :)\n저희는 당일 시장에서 공수해온 꽃만 판매하고 있습니다.\n이용해주시는 고객님들께 만족스러운 경험이 될 수 있게 노력하겠습니다.\n감사합니다.','ON','일',18,36,'4fcaeb9bcc97af56a43e57f748dd32b4.png','14be1c98-34af-4cff-96a2-07d0d885f90b-4fcaeb9bcc97af56a43e57f748dd32b4.png','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/14be1c98-34af-4cff-96a2-07d0d885f90b-4fcaeb9bcc97af56a43e57f748dd32b4.png','2023-02-14 04:32:15','315','2023-02-12 17:24:41','315','2023-02-14 16:52:52'),
(316,320,'123-12-31231','나는야 꽃가게','010-1212-1212','서울특별시','영등포구','여의도동','서울 영등포구 여의도동 1-6/501호',37.5274,126.919,'호카게가 되겠다!\n','OFF','월,화,수,목,금,토,일',18,36,'original.gif','bc93f936-fd94-4379-9287-519216e30222-original.gif','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/bc93f936-fd94-4379-9287-519216e30222-original.gif','2023-02-14 06:41:34','320','2023-02-14 06:41:34','320','2023-02-14 06:41:34'),
(319,3334,'123-45-67232','블루 플라워','123-4567-8911','대전광역시','서구','둔산동','대전광역시 서구 둔산동 1370',36.355,127.38,'꽃 한송이도 마음을 담아 만드는 블루 플라워에서 꽃길만 걸으세요','ON','월,일',18,36,'5.jpg','5fc46795-5ea1-4bda-a359-1271ffb96ed5-5.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/5fc46795-5ea1-4bda-a359-1271ffb96ed5-5.jpg','2023-02-15 06:28:42','3334','2023-02-15 06:28:42','3334','2023-02-15 07:40:03'),
(323,200,'123-12-12345','샤론플라워','010-1234-5678','대전광역시','동구','봉명동','대전광역시 유성구 봉명동 565-2',36.3554,127.335,'안녕하세요','OFF','월,화',18,44,'1.jpg','9f126959-6c36-40ea-b4ff-68678b011759-1.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/9f126959-6c36-40ea-b4ff-68678b011759-1.jpg','2023-02-15 07:07:41','3334','2023-02-15 07:07:41','3334','2023-02-15 07:07:41'),
(324,201,'123-12-12345','현암꽃플라워','010-1234-5678','대전광역시','동구','삼성동','대전광역시 동구 삼성동 352-12',36.3421,127.419,'안녕하세요','OFF','월,화',18,44,'2.jpg','1e30c8a5-1b0a-4b01-a493-935fbb39bd9c-2.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/1e30c8a5-1b0a-4b01-a493-935fbb39bd9c-2.jpg','2023-02-15 07:08:45','3334','2023-02-15 07:08:45','3334','2023-02-15 07:08:45'),
(325,202,'123-12-12345','플로리스트','010-1234-5678','대전광역시','서구','가수원동','대전광역시 서구 가수원동 762',36.3037,127.35,'안녕하세요','OFF','월,화',18,44,'3.jpg','f5fcbc61-46ca-4885-bab5-438776aa9ce1-3.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/f5fcbc61-46ca-4885-bab5-438776aa9ce1-3.jpg','2023-02-15 07:09:35','3334','2023-02-15 07:09:35','3334','2023-02-15 07:09:35'),
(326,203,'123-12-12345','테크노플라워1호점','010-1234-5678','대전광역시','유성구 ','용산동 ','대전광역시 유성구 용산동 366-12',36.4168,127.393,'안녕하세요','OFF','월,화',18,44,'6.jpg','7c83b52c-6b2e-4e8d-b605-66432d796e21-6.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/7c83b52c-6b2e-4e8d-b605-66432d796e21-6.jpg','2023-02-15 07:10:42','3334','2023-02-15 07:10:42','3334','2023-02-15 07:10:42'),
(327,204,'123-12-12345','꽃다락','010-1234-5678','대전광역시','대덕구','신탄진동','대전광역시 대덕구 신탄진동 18-11',36.4517,127.435,'안녕하세요','OFF','월,화',18,44,'7.jpg','7581f00d-1ee9-47a5-9c43-80948049f452-7.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/7581f00d-1ee9-47a5-9c43-80948049f452-7.jpg','2023-02-15 07:12:06','3334','2023-02-15 07:12:06','3334','2023-02-15 07:12:06'),
(328,205,'123-12-12345','화이트플라워','010-1234-5678','대전광역시','동구','용전동','대전광역시 동구 용전동 48-1',36.3561,127.434,'안녕하세요','OFF','월,화',18,44,'8.jpg','a3782cc4-57f1-4897-b335-29a1e6bdb3af-8.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/a3782cc4-57f1-4897-b335-29a1e6bdb3af-8.jpg','2023-02-15 07:12:55','3334','2023-02-15 07:12:55','3334','2023-02-15 07:12:55'),
(329,206,'123-12-12345','꽃소식플라워','010-1234-5678','대전광역시','서구','탄방동','대전광역시 서구 탄방동 1034',36.3474,127.395,'안녕하세요','OFF','월,화',18,44,'10.jpg','a525d948-6c81-424e-a5fd-d2a4b73b293f-10.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/a525d948-6c81-424e-a5fd-d2a4b73b293f-10.jpg','2023-02-15 07:13:48','3334','2023-02-15 07:13:48','3334','2023-02-15 07:13:48'),
(331,207,'123-12-12345','꽃사랑아트','010-1234-5678','대전광역시','서구','탄방동','대전광역시 서구 월평동 680',36.356,127.366,'안녕하세요','OFF','월,화',18,44,'11.jpg','8718a0f1-fb33-4abf-b156-9fe472c87e72-11.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/8718a0f1-fb33-4abf-b156-9fe472c87e72-11.jpg','2023-02-15 07:15:24','3334','2023-02-15 07:15:24','3334','2023-02-15 07:15:24'),
(332,208,'123-12-12345','꽃이랑새랑','010-1234-5678','대전광역시','서구','정림동','대전광역시 서구 정림동 125-2',36.3057,127.367,'안녕하세요','OFF','월,화',18,44,'9.jpg','754bdb2c-1f61-4278-af60-fc03c0f3e664-9.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/754bdb2c-1f61-4278-af60-fc03c0f3e664-9.jpg','2023-02-15 07:16:52','3334','2023-02-15 07:16:52','3334','2023-02-15 07:16:52'),
(333,209,'123-12-12345','NH플라워','010-1234-5678','대전광역시','서구','월평동','대전광역시 서구 월평동 951',36.3544,127.362,'안녕하세요','OFF','월,화',18,44,'12.jpg','1769bd36-78ce-4a17-a24b-9985aae3275e-12.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/1769bd36-78ce-4a17-a24b-9985aae3275e-12.jpg','2023-02-15 07:17:32','3334','2023-02-15 07:17:32','3334','2023-02-15 07:17:32'),
(334,210,'123-12-12345','리플라워','010-1234-5678','대전광역시','서구','둔산동','대전광역시 서구 둔산동 2123',36.3492,127.4,'안녕하세요','OFF','월,화',18,44,'13.jpg','7a288e46-e5af-497e-ab85-747285e1948c-13.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/7a288e46-e5af-497e-ab85-747285e1948c-13.jpg','2023-02-15 07:23:46','3334','2023-02-15 07:23:46','3334','2023-02-15 07:23:46'),
(336,211,'123-12-12345','리시안플라워','010-1234-5678','대전광역시','서구','둔산동','대전광역시 서구 둔산동 967',36.3556,127.377,'안녕하세요','OFF','월,화',18,44,'14.jpg','7c98d18e-b056-4c32-bc75-8ed1a3eb77d8-14.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/7c98d18e-b056-4c32-bc75-8ed1a3eb77d8-14.jpg','2023-02-15 07:24:48','3334','2023-02-15 07:24:48','3334','2023-02-15 07:24:48'),
(337,212,'123-12-12345','청사꽃집','010-1234-5678','대전광역시','서구','둔산동','대전광역시 서구 둔산동 920',36.3627,127.385,'안녕하세요','OFF','월,화',18,44,'15.jpg','1fad403e-f975-4949-b468-fb157402a4eb-15.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/1fad403e-f975-4949-b468-fb157402a4eb-15.jpg','2023-02-15 07:31:15','3334','2023-02-15 07:31:15','3334','2023-02-15 07:31:15'),
(338,213,'123-12-12345','은혜꽃집','010-1234-5678','대전광역시','서구','둔산동','대전광역시 서구 둔산동 1179',36.351,127.382,'안녕하세요','OFF','월,화',18,44,'16.jpg','bd846e0a-d530-43b2-b22e-af8455edb9d7-16.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/bd846e0a-d530-43b2-b22e-af8455edb9d7-16.jpg','2023-02-15 07:32:00','3334','2023-02-15 07:32:00','3334','2023-02-15 07:32:00'),
(339,214,'123-12-12345','오드랑뜨','010-1234-5678','대전광역시','서구','둔산동','대전광역시 서구 둔산동 967',36.3556,127.377,'안녕하세요','OFF','월,화',18,44,'17.jpg','d87fc160-3693-4cd2-b092-dcf70c735391-17.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/d87fc160-3693-4cd2-b092-dcf70c735391-17.jpg','2023-02-15 07:32:39','3334','2023-02-15 07:32:39','3334','2023-02-15 07:32:39'),
(340,215,'123-12-12345','꽃길','010-1234-5678','대전광역시','서구','둔산동','대전광역시 서구 둔산동 2101',36.3492,127.397,'안녕하세요','OFF','월,화',18,44,'18.jpg','cb226e2a-64b1-4357-96ed-3cbee34a6dd5-18.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/cb226e2a-64b1-4357-96ed-3cbee34a6dd5-18.jpg','2023-02-15 07:33:40','3334','2023-02-15 07:33:40','3334','2023-02-15 07:33:40');
/*!40000 ALTER TABLE `stores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-16 23:11:46

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `time_unit`
--

DROP TABLE IF EXISTS `time_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_unit` (
  `tu_id` bigint NOT NULL,
  `tu_time` varchar(15) NOT NULL,
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`tu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_unit`
--

LOCK TABLES `time_unit` WRITE;
/*!40000 ALTER TABLE `time_unit` DISABLE KEYS */;
INSERT INTO `time_unit` VALUES (0,'00:00',NULL,NULL,NULL,NULL),(1,'00:30',NULL,NULL,NULL,NULL),(2,'01:00',NULL,NULL,NULL,NULL),(3,'01:30',NULL,NULL,NULL,NULL),(4,'02:00',NULL,NULL,NULL,NULL),(5,'02:30',NULL,NULL,NULL,NULL),(6,'03:00',NULL,NULL,NULL,NULL),(7,'03:30',NULL,NULL,NULL,NULL),(8,'04:00',NULL,NULL,NULL,NULL),(9,'04:30',NULL,NULL,NULL,NULL),(10,'05:00',NULL,NULL,NULL,NULL),(11,'05:30',NULL,NULL,NULL,NULL),(12,'06:00',NULL,NULL,NULL,NULL),(13,'06:30',NULL,NULL,NULL,NULL),(14,'07:00',NULL,NULL,NULL,NULL),(15,'07:30',NULL,NULL,NULL,NULL),(16,'08:00',NULL,NULL,NULL,NULL),(17,'08:30',NULL,NULL,NULL,NULL),(18,'09:00',NULL,NULL,NULL,NULL),(19,'09:30',NULL,NULL,NULL,NULL),(20,'10:00',NULL,NULL,NULL,NULL),(21,'10:30',NULL,NULL,NULL,NULL),(22,'11:00',NULL,NULL,NULL,NULL),(23,'11:30',NULL,NULL,NULL,NULL),(24,'12:00',NULL,NULL,NULL,NULL),(25,'12:30',NULL,NULL,NULL,NULL),(26,'13:00',NULL,NULL,NULL,NULL),(27,'13:30',NULL,NULL,NULL,NULL),(28,'14:00',NULL,NULL,NULL,NULL),(29,'14:30',NULL,NULL,NULL,NULL),(30,'15:00',NULL,NULL,NULL,NULL),(31,'15:30',NULL,NULL,NULL,NULL),(32,'16:00',NULL,NULL,NULL,NULL),(33,'16:30',NULL,NULL,NULL,NULL),(34,'17:00',NULL,NULL,NULL,NULL),(35,'17:30',NULL,NULL,NULL,NULL),(36,'18:00',NULL,NULL,NULL,NULL),(37,'18:30',NULL,NULL,NULL,NULL),(38,'19:00',NULL,NULL,NULL,NULL),(39,'19:30',NULL,NULL,NULL,NULL),(40,'20:00',NULL,NULL,NULL,NULL),(41,'20:30',NULL,NULL,NULL,NULL),(42,'21:00',NULL,NULL,NULL,NULL),(43,'21:30',NULL,NULL,NULL,NULL),(44,'22:00',NULL,NULL,NULL,NULL),(45,'22:30',NULL,NULL,NULL,NULL),(46,'23:00',NULL,NULL,NULL,NULL),(47,'23:30',NULL,NULL,NULL,NULL),(48,'24:00',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `time_unit` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:06:01

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `u_id` bigint NOT NULL AUTO_INCREMENT,
  `u_role` varchar(15) NOT NULL,
  `u_email` varchar(50) NOT NULL,
  `u_nickname` varchar(50) DEFAULT NULL,
  `u_phone_number` varchar(50) DEFAULT NULL,
  `u_refresh_token` varchar(10000) DEFAULT NULL,
  `u_withdrawal_date` date DEFAULT NULL,
  `u_soft_delete` tinyint DEFAULT '0',
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`u_id`),
  UNIQUE KEY `u_email_UNIQUE` (`u_email`),
  UNIQUE KEY `u_nickname_UNIQUE` (`u_nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=3358 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (200,'STORE','test1@gmail.com',NULL,NULL,'REFRESHTEST1',NULL,0,NULL,NULL,NULL,NULL),
(201,'STORE','test2@gmail.com',NULL,NULL,'REFRESHTEST2',NULL,0,NULL,NULL,NULL,NULL),
(202,'STORE','test3@gmail.com',NULL,NULL,'REFRESHTEST3',NULL,0,NULL,NULL,NULL,NULL),
(203,'STORE','test4@gmail.com',NULL,NULL,'REFRESHTEST4',NULL,0,NULL,NULL,NULL,NULL),
(204,'STORE','test5@gmail.com',NULL,NULL,'REFRESHTEST5',NULL,0,NULL,NULL,NULL,NULL),
(205,'STORE','test6@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(206,'STORE','test7@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(207,'STORE','test8@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(208,'STORE','test9@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(209,'STORE','test10@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(210,'STORE','test11@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(211,'STORE','test12@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(212,'STORE','test13@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(213,'STORE','test14@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(214,'STORE','test15@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(215,'STORE','test16@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3335,'CUSTOMER','test_c1@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3336,'CUSTOMER','test_c2@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3337,'CUSTOMER','test_c3@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3338,'CUSTOMER','test_c4@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3339,'CUSTOMER','test_c5@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3340,'CUSTOMER','test_c6@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3341,'CUSTOMER','test_c7@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3342,'CUSTOMER','test_c9@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3343,'CUSTOMER','test_c10@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3344,'CUSTOMER','test_c11@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3345,'CUSTOMER','test_c12@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),
(3346,'CUSTOMER','test_c13@gmail.com',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:05:59

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `rev_id` bigint NOT NULL AUTO_INCREMENT,
  `u_id` bigint DEFAULT NULL,
  `s_id` bigint DEFAULT NULL,
  `o_id` bigint DEFAULT NULL,
  `rev_content` varchar(1000) NOT NULL,
  `rev_create_date` datetime DEFAULT NULL,
  `rev_img_original_name` varchar(150) DEFAULT NULL,
  `rev_img_new_name` varchar(150) DEFAULT NULL,
  `rev_img_path` varchar(500) DEFAULT NULL,
  `rev_img_upload_time` timestamp NULL DEFAULT NULL,
  `rev_soft_delete` tinyint DEFAULT '0',
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`rev_id`),
  KEY `u_id_idx` (`u_id`),
  KEY `s_id_idx` (`s_id`),
  KEY `rev_o_id_idx` (`o_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (5,318,315,159,'꽃이 너무 이뻐요~ 잘 받았습니다!','2023-02-15 22:43:56','4fcaeb9bcc97af56a43e57f748dd32b4.png','dcaf4db2-cd96-4b66-bcc3-a0fa5e556793-4fcaeb9bcc97af56a43e57f748dd32b4.png','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/dcaf4db2-cd96-4b66-bcc3-a0fa5e556793-4fcaeb9bcc97af56a43e57f748dd32b4.png','2023-02-15 03:00:56',0,'318','2023-02-15 03:00:56','318','2023-02-15 03:00:56'),
(8,318,315,211,'이쁜꽃입니다~~~','2023-02-16 16:18:27','null.png','34625c9d-e6e3-4ca8-b677-c7bdc61487b8-null.png','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/34625c9d-e6e3-4ca8-b677-c7bdc61487b8-null.png','2023-02-16 07:18:27',0,'318','2023-02-16 07:18:27','318','2023-02-16 07:18:27'),
(9,3347,315,192,'좋았어요','2023-02-16 17:14:42','null.png','51fdf5fe-0a01-4d2f-9687-4f983211539b-null.png','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/51fdf5fe-0a01-4d2f-9687-4f983211539b-null.png','2023-02-16 08:14:42',0,'3347','2023-02-16 08:14:42','3347','2023-02-16 08:14:42'),
(10,318,315,218,'부모님이 정말 좋아하셨어요~','2023-02-16 22:18:38','null.png','a81d7960-c3d0-464f-86f7-fa9758ae5e7f-null.png','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/a81d7960-c3d0-464f-86f7-fa9758ae5e7f-null.png','2023-02-16 13:18:38',0,'318','2023-02-16 13:18:38','318','2023-02-16 13:18:38');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:06:02

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `rep_id` bigint NOT NULL AUTO_INCREMENT,
  `o_id` bigint NOT NULL,
  `rep_date` timestamp NOT NULL,
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`rep_id`),
  KEY `o_id_idx` (`o_id`),
  CONSTRAINT `o_id` FOREIGN KEY (`o_id`) REFERENCES `orders` (`o_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:05:59

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipts` (
  `rec_id` bigint NOT NULL AUTO_INCREMENT,
  `rec_type` varchar(15) NOT NULL,
  `rec_orderer` varchar(50) NOT NULL,
  `rec_orderer_phone_number` varchar(50) DEFAULT NULL,
  `rec_gift_message` varchar(200) DEFAULT NULL,
  `rec_recipient` varchar(50) DEFAULT NULL,
  `rec_recipient_phone_number` varchar(50) DEFAULT NULL,
  `rec_receipt_date` date DEFAULT NULL,
  `rec_delivery_destination` varchar(100) DEFAULT NULL,
  `rec_status` varchar(15) DEFAULT '"UNDONE"',
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`rec_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES (38,'PICKUP','임경민','010-1111-1111','안뇽 모짜',NULL,NULL,NULL,NULL,'UNDONE','3347','2023-02-16 00:11:16','3347','2023-02-16 00:11:16'),
(45,'DEILIVERY','원창님','01012341234','ㅊㅋㅊㅋ','기싸피','01064646464',NULL,'서울 동작구 상도동 323-25/','UNDONE','318','2023-02-16 06:36:51','318','2023-02-16 06:36:51'),
(51,'PICKUP','원창님','01012341234','ㅊㅋㅊㅋ',NULL,NULL,NULL,NULL,'DONE','318','2023-02-16 07:06:44','318','2023-02-16 07:06:44'),
(52,'PICKUP','원창님','01012341234','ㅊㅋㅊㅋ',NULL,NULL,NULL,NULL,'DONE','318','2023-02-16 08:49:00','315','2023-02-16 14:26:39'),
(55,'DEILIVERY','원창님','01012341238','축하해~','김싸피','01010101010','2023-02-17','대전 대덕구 문평동 400-4/','DONE','318','2023-02-16 15:04:45','315','2023-02-16 15:09:12'),
(56,'DEILIVERY','원창님','01012341238','축하해~~','김싸피','01012312313',NULL,'경기 성남시 분당구 백현동 582-7/','UNDONE','318','2023-02-16 15:07:26','318','2023-02-16 15:07:26'),
(57,'PICKUP','원창님','01012341238','나는선물카드입니다.',NULL,NULL,NULL,NULL,'UNDONE','318','2023-02-16 15:51:11','318','2023-02-16 15:51:11');
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:06:00

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `p_id` bigint NOT NULL AUTO_INCREMENT,
  `p_name` varchar(100) NOT NULL,
  `p_desc` varchar(500) NOT NULL,
  `p_price` int NOT NULL,
  `s_id` bigint DEFAULT NULL,
  `p_img_original_name` varchar(150) DEFAULT NULL,
  `p_img_new_name` varchar(150) DEFAULT NULL,
  `p_img_path` varchar(500) DEFAULT NULL,
  `p_img_upload_time` timestamp NULL DEFAULT NULL,
  `p_soft_delete` tinyint DEFAULT '0',
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`p_id`),
  KEY `s_id_idx` (`s_id`),
  CONSTRAINT `p_s_id` FOREIGN KEY (`s_id`) REFERENCES `stores` (`s_id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'이달의 꽃','당일 가장 상태가 좋은 꽃들로만 꽃다발을 만들어 보내드리고 있습니다. 제일 무난한 구성으로 고객님들께 가장 인기가 많습니다 :)',30000,NULL,'bouquet-4024176_960_720.jpg','1fba710b-ae67-4037-a190-b7393eb413e5-bouquet-4024176_960_720.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/1fba710b-ae67-4037-a190-b7393eb413e5-bouquet-4024176_960_720.jpg','2023-02-14 16:54:32',0,NULL,NULL,'315','2023-02-14 16:54:32'),
(108,'분홍장미꽃다발','분홍장미와 어울리는 계절꽃으로 다양한 매력이 있는 꽃다발입니다.',58900,319,'분홍장미꽃다발.jpg','3bd20b6e-7a47-4906-beb6-bfa34b519917-분홍장미꽃다발.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/3bd20b6e-7a47-4906-beb6-bfa34b519917-%EB%B6%84%ED%99%8D%EC%9E%A5%EB%AF%B8%EA%BD%83%EB%8B%A4%EB%B0%9C.jpg','2023-02-15 07:46:08',0,'3334','2023-02-15 07:46:08','3334','2023-02-15 07:46:08'),
(109,'수줍은고백','수줍은고백은 분홍 장미를 주요 소재로 한 계절 꽃다발입니다..',52000,319,'수줍은고백.jpg','660418d9-ea2c-4c2a-96af-3d2d26448933-수줍은고백.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/660418d9-ea2c-4c2a-96af-3d2d26448933-%EC%88%98%EC%A4%8D%EC%9D%80%EA%B3%A0%EB%B0%B1.jpg','2023-02-15 07:46:26',0,'3334','2023-02-15 07:46:26','3334','2023-02-15 07:46:26'),
(110,'아리따움','아리따움은 빨간장미와 그린블루소재로 구성된 꽃다발입니다.',72000,319,'아리따움.jpg','8edfb1c0-ca39-45b1-8a20-b65b0b6b0875-아리따움.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/8edfb1c0-ca39-45b1-8a20-b65b0b6b0875-%EC%95%84%EB%A6%AC%EB%94%B0%EC%9B%80.jpg','2023-02-15 07:46:44',0,'3334','2023-02-15 07:46:44','3334','2023-02-15 07:46:44'),
(111,'클림트키스','클림트키스의 연인들처럼 황홀히 취하게 만드는 매력의 꽃다발',96900,319,'클림트키스.jpg','4567fe7d-4eff-4edc-8fd8-c318ab91a6a0-클림트키스.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/4567fe7d-4eff-4edc-8fd8-c318ab91a6a0-%ED%81%B4%EB%A6%BC%ED%8A%B8%ED%82%A4%EC%8A%A4.jpg','2023-02-15 07:46:57',0,'3334','2023-02-15 07:46:57','3334','2023-02-15 07:46:57'),
(112,'양산을 든 여인','맑고 신선한 느낌의 수국 꽃다발',70000,319,'양산을 든 여인.png','636a1d55-72b0-4e41-a4f5-0ce02f919204-양산을 든 여인.png','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/636a1d55-72b0-4e41-a4f5-0ce02f919204-%EC%96%91%EC%82%B0%EC%9D%84%20%EB%93%A0%20%EC%97%AC%EC%9D%B8.png','2023-02-15 07:49:46',0,'3334','2023-02-15 07:49:46','3334','2023-02-15 07:49:46'),
(113,'지금 이 순간','지금 이 순간은 분홍색 계열의 계절꽃으로 구성된 꽃다발입니다.',67000,319,'지금 이 순간.jpg','a529140d-9cf0-4b0d-b9d5-cdf7ae2897e7-지금 이 순간.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/a529140d-9cf0-4b0d-b9d5-cdf7ae2897e7-%EC%A7%80%EA%B8%88%20%EC%9D%B4%20%EC%88%9C%EA%B0%84.jpg','2023-02-15 07:49:58',0,'3334','2023-02-15 07:49:58','3334','2023-02-15 07:49:58'),
(114,'다정다감','소담한 모습이 탐스러운 다정다감',74000,319,'다정다감.jpg','f963bcdc-199a-4756-9816-c8718799e265-다정다감.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/f963bcdc-199a-4756-9816-c8718799e265-%EB%8B%A4%EC%A0%95%EB%8B%A4%EA%B0%90.jpg','2023-02-15 07:50:12',0,'3334','2023-02-15 07:50:12','3334','2023-02-15 07:50:12'),
(115,'핑크리시안','오늘 하루를 핑크빛으로 물들일 연핑크 꽃다발입니다.',51900,319,'핑크리시안.jpg','75c280de-476a-4d50-b7cf-0ad6ca2e61d3-핑크리시안.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/75c280de-476a-4d50-b7cf-0ad6ca2e61d3-%ED%95%91%ED%81%AC%EB%A6%AC%EC%8B%9C%EC%95%88.jpg','2023-02-15 07:50:25',0,'3334','2023-02-15 07:50:25','3334','2023-02-15 07:50:25'),
(116,'햇살같은너에게','하얀 꽃을 주요 소재로 한 감성 꽃다발, \'햇살같은 너에게\'입니다.',52000,319,'햇살같은너에게.jpg','cd490941-fb1e-4c0b-ba4f-56e32dd1b00f-햇살같은너에게.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/cd490941-fb1e-4c0b-ba4f-56e32dd1b00f-%ED%96%87%EC%82%B4%EA%B0%99%EC%9D%80%EB%84%88%EC%97%90%EA%B2%8C.jpg','2023-02-15 07:50:38',0,'3334','2023-02-15 07:50:38','3334','2023-02-15 07:50:38'),
(117,'새벽하늘','시원한 듯, 차가운 듯 청량하고 맑은 기운이 느껴지는 꽃다발입니다.',55000,319,'새벽하늘.jpg','9c05eeb2-e9c8-4ea1-844e-d9957401c8e4-새벽하늘.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/9c05eeb2-e9c8-4ea1-844e-d9957401c8e4-%EC%83%88%EB%B2%BD%ED%95%98%EB%8A%98.jpg','2023-02-15 07:50:49',0,'3334','2023-02-15 07:50:49','3334','2023-02-15 07:50:49'),
(118,'다정다감','이른 봄에 피는 소소하지만 정이 가는 꽃들을 모아 놓은 꽃다발입니다.',25500,315,'다정다감.jpg','68137ac4-bdf5-4797-bf66-00a6f2daa3a7-다정다감.jpg','https://hurry-up-push-bucket.s3.ap-northeast-2.amazonaws.com/68137ac4-bdf5-4797-bf66-00a6f2daa3a7-%EB%8B%A4%EC%A0%95%EB%8B%A4%EA%B0%90.jpg','2023-02-16 15:49:51',0,'315','2023-02-16 15:49:51','315','2023-02-16 15:49:51');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:05:59

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `o_id` bigint NOT NULL AUTO_INCREMENT,
  `u_id` bigint NOT NULL,
  `o_num` varchar(50) NOT NULL,
  `o_date` date DEFAULT (curdate()),
  `o_status` varchar(15) DEFAULT NULL,
  `o_type` varchar(15) DEFAULT NULL,
  `o_payment` int DEFAULT '0',
  `o_payment_num` varchar(50) DEFAULT NULL,
  `o_payment_status` varchar(15) DEFAULT NULL,
  `o_review` tinyint DEFAULT '0',
  `s_id` bigint NOT NULL,
  `p_id` bigint DEFAULT NULL,
  `con_id` bigint DEFAULT NULL,
  `rec_id` bigint DEFAULT NULL,
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`o_id`),
  UNIQUE KEY `o_num_UNIQUE` (`o_num`),
  UNIQUE KEY `o_payment_num_UNIQUE` (`o_payment_num`),
  KEY `u_id_idx` (`u_id`),
  KEY `s_id_idx` (`s_id`),
  KEY `p_id_idx` (`p_id`),
  KEY `o_con_id_idx` (`con_id`),
  KEY `o_rec_id_idx` (`rec_id`),
  CONSTRAINT `o_con_id` FOREIGN KEY (`con_id`) REFERENCES `conferences` (`con_id`),
  CONSTRAINT `o_p_id` FOREIGN KEY (`p_id`) REFERENCES `products` (`p_id`),
  CONSTRAINT `o_rec_id` FOREIGN KEY (`rec_id`) REFERENCES `receipts` (`rec_id`),
  CONSTRAINT `o_s_id` FOREIGN KEY (`s_id`) REFERENCES `stores` (`s_id`),
  CONSTRAINT `o_u_id` FOREIGN KEY (`u_id`) REFERENCES `users` (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (193,3347,'20230216193','2023-02-16','ACCEPT','NOW',15000,'T3ed74a54a466e299edc','DONE',1,315,1,119,38,'3347','2023-02-16 00:09:26','3353','2023-02-16 00:46:01'),
(211,318,'20230216211','2023-02-16','ACCEPT','NOW',50000,NULL,'DONE',1,315,1,134,45,'318','2023-02-16 06:36:19','318','2023-02-16 07:18:27'),
(215,318,'20230216215','2023-02-16','ACCEPT','NOW',50000,'T3edd660003e7c989b3a','DONE',0,315,1,138,51,'318','2023-02-16 07:06:04','318','2023-02-16 07:08:47'),
(218,318,'20230216218','2023-02-16','ACCEPT','NOW',50000,'T3ee33224a466e29a96e','DONE',1,315,1,140,52,'318','2023-02-16 08:48:01','318','2023-02-16 13:44:03'),
(233,318,'20230217233','2023-02-17','COMPLETED','NOW',25000,'T3ee460e003e7c98a14c','DONE',0,315,1,150,55,'318','2023-02-16 15:03:57','315','2023-02-16 15:09:12'),
(234,318,'20230217234','2023-02-17','ACCEPT','NOW',50000,'T3ee46af003e7c98a155','UNDONE',0,315,1,151,56,'318','2023-02-16 15:06:58','318','2023-02-16 15:07:28'),
(235,318,'20230217235','2023-02-17','ACCEPT','NOW',50000,'T3ee50f64a466e29aa4f','DONE',0,315,1,152,57,'318','2023-02-16 15:50:22','318','2023-02-16 15:51:36');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:06:03

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `conferences`
--

DROP TABLE IF EXISTS `conferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conferences` (
  `con_id` bigint NOT NULL AUTO_INCREMENT,
  `con_reservation_date` date DEFAULT NULL,
  `con_reservation_time` bigint DEFAULT NULL,
  `con_start_time` time DEFAULT NULL,
  `con_session_id` varchar(100) DEFAULT NULL,
  `con_token` varchar(300) DEFAULT NULL,
  `con_link` varchar(400) DEFAULT NULL,
  `con_status` varchar(15) DEFAULT '"WAITING"',
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`con_id`),
  UNIQUE KEY `con_link_UNIQUE` (`con_link`),
  KEY `con_reservation_time_idx` (`con_reservation_time`),
  CONSTRAINT `con_reservation_time` FOREIGN KEY (`con_reservation_time`) REFERENCES `time_unit` (`tu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conferences`
--

LOCK TABLES `conferences` WRITE;
/*!40000 ALTER TABLE `conferences` DISABLE KEYS */;
INSERT INTO `conferences` VALUES (119,'2023-02-16',NULL,'09:10:46','20230216193','wss://i8b203.p.ssafy.io:8445?sessionId=20230216193&token=tok_QQq4rlPlMPQFgapx',NULL,'WAITING','315','2023-02-16 00:10:47','315','2023-02-16 00:10:47'),
(134,'2023-02-16',NULL,'15:36:20','20230216211','wss://i8b203.p.ssafy.io:8445?sessionId=20230216211&token=tok_LfW3wmkAQXBwhWWl',NULL,'COMPLETED','315','2023-02-16 06:36:21','315','2023-02-16 06:36:21'),
(138,'2023-02-16',NULL,'16:06:05','20230216215','wss://i8b203.p.ssafy.io:8445?sessionId=20230216215&token=tok_EBcgJTN9UtITGJnS',NULL,'COMPLETED','315','2023-02-16 07:06:06','315','2023-02-16 07:06:06'),
(140,'2023-02-16',NULL,'17:48:41','20230216218','wss://i8b203.p.ssafy.io:8445?sessionId=20230216218&token=tok_CmxRTWVVUtOeucGo',NULL,'COMPLETED','315','2023-02-16 08:48:41','315','2023-02-16 08:48:41'),
(150,'2023-02-17',NULL,'00:04:10','20230217233','wss://i8b203.p.ssafy.io:8445?sessionId=20230217233&token=tok_AbH9N07hTIjbg6Rq',NULL,'COMPLETED','315','2023-02-16 15:04:10','318','2023-02-16 15:04:46'),
(151,'2023-02-17',NULL,'00:07:04','20230217234','wss://i8b203.p.ssafy.io:8445?sessionId=20230217234&token=tok_JPC5PRLXgspRHrOI',NULL,'COMPLETED','315','2023-02-16 15:07:04','318','2023-02-16 15:07:28'),
(152,'2023-02-17',NULL,'00:50:28','20230217235','wss://i8b203.p.ssafy.io:8445?sessionId=20230217235&token=tok_ZuVHxv16Ny8ARFUu',NULL,'COMPLETED','315','2023-02-16 15:50:29','318','2023-02-16 15:51:19');
/*!40000 ALTER TABLE `conferences` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:06:02

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookmarks`
--

DROP TABLE IF EXISTS `bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmarks` (
  `b_id` bigint NOT NULL AUTO_INCREMENT,
  `u_id` bigint NOT NULL,
  `s_id` bigint NOT NULL,
  `creator` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updater` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`b_id`),
  KEY `u_id_idx` (`u_id`),
  KEY `s_id_idx` (`s_id`),
  CONSTRAINT `b_s_id` FOREIGN KEY (`s_id`) REFERENCES `stores` (`s_id`) ON DELETE CASCADE,
  CONSTRAINT `b_u_id` FOREIGN KEY (`u_id`) REFERENCES `users` (`u_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmarks`
--

LOCK TABLES `bookmarks` WRITE;
/*!40000 ALTER TABLE `bookmarks` DISABLE KEYS */;
INSERT INTO `bookmarks` VALUES (57,3335,319,NULL,NULL,NULL,NULL),
(58,3336,319,NULL,NULL,NULL,NULL),
(59,3337,319,NULL,NULL,NULL,NULL),
(60,3338,319,NULL,NULL,NULL,NULL),
(61,3339,319,NULL,NULL,NULL,NULL),
(62,3340,319,NULL,NULL,NULL,NULL),
(63,3341,319,NULL,NULL,NULL,NULL),
(64,3342,319,NULL,NULL,NULL,NULL),
(65,3343,319,NULL,NULL,NULL,NULL),
(66,3344,319,NULL,NULL,NULL,NULL),
(68,3349,319,'3349','2023-02-15 15:08:35','3349','2023-02-15 15:08:35'),
(76,3356,315,'3356','2023-02-16 08:05:04','3356','2023-02-16 08:05:04'),
(77,318,315,'318','2023-02-16 13:39:06','318','2023-02-16 13:39:06'),
(78,3356,319,'3356','2023-02-16 15:03:31','3356','2023-02-16 15:03:31'),
(82,315,319,'315','2023-02-16 16:00:20','315','2023-02-16 16:00:20');
/*!40000 ALTER TABLE `bookmarks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:06:00


-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8b203.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:06:01
